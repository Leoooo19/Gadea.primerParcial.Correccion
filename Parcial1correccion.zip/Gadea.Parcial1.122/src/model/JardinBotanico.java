package model;

import excepciones.PlantaRepetidaException;
import interfaces.Podable;
import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {

    private final List<Planta> plantas;

    public JardinBotanico() {
        plantas = new ArrayList<>();
    }

    public void validarPlanta(Planta planta) throws PlantaRepetidaException {
        for (Planta p : plantas) {
            if (p.equals(planta)) {
                throw new PlantaRepetidaException("Ya existe una planta duplicada: " + planta);
            }
        }
    }
    
    public void agregarPlanta(Planta planta) {
        try {
            validarPlanta(planta);
            plantas.add(planta);
        } catch(PlantaRepetidaException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void mostrarPlantas() {
        for (Planta p : plantas) {
            System.out.println(p);
        }
    }

    public void podarPlantas() {
        for (Planta p : plantas) {
            if (p instanceof Podable podable) {
                podable.podar();

            }
        }
    }

    public void filtrarPorTemporadaFlorecimiento(Temporada temporada) {
        for (Planta p : plantas) {
            if (p instanceof Flor flor) {
                if (flor.getTemporada() == temporada) {
                    System.out.println(flor);
                }
            }
        }
    }
}

package Principal;

import excepciones.PlantaRepetidaException;
import model.Arbol;
import model.Arbusto;
import model.Flor;
import model.JardinBotanico;
import model.Planta;
import model.Temporada;

public class Principal {

    private static Planta nuevaPlanta;

    public static void main(String[] args) throws PlantaRepetidaException {
        JardinBotanico jardin = new JardinBotanico();
       
        

        jardin.agregarPlanta(new Arbol("Roble", "Zona Norte", "Templado", 20));
        jardin.agregarPlanta(new Arbol("Roble", "Zona Norte", "Calido", 21)); //prueba excepcion
        jardin.agregarPlanta(new Arbusto("Duro", "Zona Este", "Arido", 6));
        jardin.agregarPlanta(new Arbol("Fino", "Zona Oeste", "Frio", 6));
        jardin.agregarPlanta(new Flor("Tulipan", "Zona Sur", "Calido", Temporada.PRIMAVERA));

        jardin.mostrarPlantas();
        jardin.podarPlantas();

        
    }

}

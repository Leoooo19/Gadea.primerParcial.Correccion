package interfaces;

public interface Aromatica {

    void desprenderAroma();
}

package excepciones;

public class PlantaRepetidaException extends RuntimeException {

    public PlantaRepetidaException(String mensaje) {
        super(mensaje);
    }
}